## CastarSDK Integrated Document

**Step 1**
Add the castar.jar file to your app module’s libs folder

**Step 2**
Implement sdk in your app module's build.gradle file

```kotlin
implementation(files("libs/castar.jar"))
```
**Step 3**
Add internet permission in your app module's AndroidManifest.xml file.
```xml
<uses-permission android:name="android.permission.INTERNET" />
```
**Step 4**
set usesCleartextTraffic="true" in your manifest 
```xml
<application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:usesCleartextTraffic="true"
>
```
**Step 5**
start the sdk
```kotlin
Client.Start(context,"your clientId")
```

If you want to verify if the SDK starts successfully, you can add the following listeners，when it returns ‘connected’ whitch means it start successfully

java
```java
Client.setListener(new StatusListener() {
            @Override
            public void onClientStatusConnectChanged(String s) {
                //need to deal it in your UI thread
            }
        });
```
kotlin
```kotlin
Client.setListener(object : StatusListener {
            override fun onClientStatusConnectChanged(p0: String?) {
               //need to deal it in your UI thread
            }
        })
```
